<?php
/**
 * Created by PhpStorm.
 * User: 17110023
 * Date: 2019/07/26
 * Time: 13:16
 */

namespace App;
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class AddSchedule
{
    public function addStore(Request $request)
    {
        \DB::table('tasks')->insert([
            'title' => $request->title,
            'class' => $request->class,
            'place' => $request->place,
            'start_date' => $request->start_date,
            'start_time' => $request->start_time,
            'end_date' => $request->end_date,
            'end_time' => $request->end_time,
            'remarks' => $request->remarks,
        ]);
    }

/*
        //DBにデータを保存
    public function addStore(Request $request){
            // 新規インスタンス作成
        $tasks = \DB::table('tasks')->get();
        //      $tasks = new AddSchedule;
            // インスタンスに受け取った値を格納
        $tasks->title = $request->title;
        $tasks->class = $request->request;
        $tasks->place = $request->place;
        $tasks->start_date= $request->start_date;
        $tasks->start_time = $request->start_time;
        $tasks->end_date = $request->end_date;
        $tasks->end_time = $request->end_time;
        $tasks->remarks = $request->remarks;
            // データベースにデータを追加
        $tasks->save();
    }
*/
            // データを編集する
        public function updateData(Request $request) {

            $tasks = new tasks;
            // 指定のデータを更新
            $tasks->title = $request->title;
            $tasks->class = $request->request;
            $tasks->place = $request->place;
            $tasks->start_date= $request->start_date;
            $tasks->start_time = $request->start_time;
            $tasks->end_date = $request->end_time;
            $tasks->end_time = $request->end_time;
            $tasks->remarks = $request->remarks;
            $tasks = tasks::where('id', $request->id)->first();

                // データベースのデータを更新
            $tasks->save();
}



}