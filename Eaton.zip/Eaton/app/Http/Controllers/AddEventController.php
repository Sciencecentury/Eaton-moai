<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\AddSchedule;
use Illminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
class AddEventController extends Controller
{

    public function addStore(Request $request){

        $task = new AddSchedule;
        $task.$this->addStore($request);

        // 新規インスタンス作成
        //$tasks = \DB::table('tasks')->get();
/*
        \DB::table('tasks')->insert([
            'title' => $request->title,
            'class' => $request->class,
            'place' => $request->place,
            'start_date' => $request->start_date,
            'start_time' => $request->start_time,
            'end_date' => $request->end_date,
            'end_time' => $request->end_time,
            'remarks' => $request->remarks,
        ]);
*/
/*
        //      $tasks = new AddSchedule;
        // インスタンスに受け取った値を格納
        $tasks->title = $request->title;
        $tasks->class = $request->request;
        $tasks->place = $request->place;
        $tasks->start_date= $request->start_date;
        $tasks->start_time = $request->start_time;
        $tasks->end_date = $request->end_date;
        $tasks->end_time = $request->end_time;
        $tasks->remarks = $request->remarks;
        // データベースにデータを追加
        $tasks->save();
*/
    }

    public function addEvent(Request $request){
 //       $tasks = new AddSchedule;
 //       $tasks.addStore();
        echo $title =  $request->titles;
        echo $class =  $request->class;
        echo $place =  $request->place;
        echo $start_date =  $request->start_date;
        echo $start_time =  $request->start_time;
        echo $end_date =  $request->end_date;
        echo $end_time =  $request->end_time;
        echo $remarks =  $request->remarks;
        //return redirect('tes');

    }
}
