<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;


class AddEventController extends Controller
{
    public function addEvent(Request $request){
        echo $title =  $request->title;
        echo $class =  $request->class;
        echo $place =  $request->place;
        echo $start_date =  $request->start_date;
        echo $start_time =  $request->start_time;
        echo $end_date =  $request->end_date;
        echo $end_time =  $request->end_time;
        echo $remarks =  $request->remarks;
        //return redirect('tes');
    }
}
