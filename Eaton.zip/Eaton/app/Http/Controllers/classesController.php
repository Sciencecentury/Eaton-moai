<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class classesController extends Controller
{
    //

    public function create(){
        $prefectures = \App\Prefecture::orderBy('code','asc')->pluck('name', 'code');
        $prefectures = $prefectures -> prepend('都道府県', '');

        return view('items.create')->with(['prefectures' => $prefectures]);
    }







}
