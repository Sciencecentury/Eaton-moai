<?php
/**
 * Created by PhpStorm.
 * User: 17110023
 * Date: 2019/07/26
 * Time: 13:16
 */

namespace App;


class DBinsert
{




}