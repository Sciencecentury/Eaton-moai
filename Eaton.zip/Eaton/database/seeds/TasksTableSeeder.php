<?php

use Illuminate\Database\Seeder;

class TasksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $task = [
            'title'=>'test1',
            'class'=>'test2',
            'place'=>'test3',
            'start_date'=>'2019-07-19',
            'start_time'=>'00:00',
            'end_date'=>'2019-07-20',
            'end_time'=>'00:00',
            'remarks'=>'test8'

            ];
        DB::table('tasks')->insert($task);

    }
}
