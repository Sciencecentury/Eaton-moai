<?php

use Illuminate\Database\Seeder;

class ClassesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
     $class = [
         ['class'=>'あじさい組'],
         ['class'=>'いじさい組'],
         ['class'=>'うじさい組']

     ];
        DB::table('classes')->insert($class);
    }
}
