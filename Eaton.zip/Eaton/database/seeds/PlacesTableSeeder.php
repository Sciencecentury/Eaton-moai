<?php

use Illuminate\Database\Seeder;

class PlacesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $place = [
            ['place'=>'庭1'],
            ['place'=>'庭2'],
            ['place'=>'庭3']

        ];
        DB::table('places')->insert($place);
    }
}
