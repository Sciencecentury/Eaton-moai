<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<h1>予定の追加</h1>

<form action="<?php echo e(url('/eventAdd')); ?>" method = "post">
<?php echo csrf_field(); ?>
    <!-- タイトル設定部分 -->
    タイトル<input type = "text" name="title"><br>

    <!-- 組設定部分 -->

    <?php
        $classes = \DB::table('classes')->get();

    ?>
    組<select name="class">
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value='<?php echo e($class->class); ?>'><?php echo e($class->class); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>



    <!-- 場所設定部分 -->
    <?php
        $places = \DB::table('places')->get();

    ?>
    場所<select name="place">
        <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value='<?php echo e($place->place); ?>'><?php echo e($place->place); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>


    <!-- 時間設定部分 -->
    <div>
        <div>
            <label>日時</label><br>
            <span>開始日時：</span>
            <input type = "date" name = "start_date" id = "startDay">
            <input type = "time" name = "start_time" id = "starTime">
        </div>

        <div>
            <span  style = "font-size : 20px;">終了日時：</span>
            <input type = "date" name = "end_date" id = "endDay">
            <input type = "time" name = "end_time" id = "endTime">
        </div>
    </div>


    <!-- 備考記述部分 -->
    備考<input type = "text" name="remarks"><br>


    <!-- 追加・キャンセルボタン -->
    <input type = "submit" value = "追加">
    <a href = "../calendar/calendar.php">キャンセル</a>

</form>



</body>
</html><?php /**PATH C:\xampp\htdocs\Eaton\resources\views/addEvent2.blade.php ENDPATH**/ ?>