<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<h1>予定の追加</h1>

<form action="{{url('/eventAdd')}}" method = "post">
@csrf
    <!-- タイトル設定部分 -->
    タイトル<input type = "text" name="title"><br>

    <!-- 組設定部分 -->

    @php
        $classes = \DB::table('classes')->get();

    @endphp
    組<select name="class">
        @foreach ($classes as $class)
            <option value='{{$class->class}}'>{{$class->class}}</option>
        @endforeach
    </select><br>



    <!-- 場所設定部分 -->
    @php
        $places = \DB::table('places')->get();

    @endphp
    場所<select name="place">
        @foreach ($places as $place)
            <option value='{{$place->place}}'>{{$place->place}}</option>
        @endforeach
    </select><br>


    <!-- 時間設定部分 -->
    <div>
        <div>
            <label>日時</label><br>
            <span>開始日時：</span>
            <input type = "date" name = "start_date" id = "startDay">
            <input type = "time" name = "start_time" id = "starTime">
        </div>

        <div>
            <span  style = "font-size : 20px;">終了日時：</span>
            <input type = "date" name = "end_date" id = "endDay">
            <input type = "time" name = "end_time" id = "endTime">
        </div>
    </div>


    <!-- 備考記述部分 -->
    備考<input type = "text" name="remarks"><br>


    <!-- 追加・キャンセルボタン -->
    <input type = "submit" value = "追加">
    <a href = "../calendar/calendar.php">キャンセル</a>

</form>



</body>
</html>